"""
Utility modules for the Energy Anomaly Detection System
"""