"""
Energy Anomaly Detection System
Root package initialization
"""