"""
Custom styling for the Energy Anomaly Detection System
"""