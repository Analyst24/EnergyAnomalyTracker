"""
Machine learning models for the Energy Anomaly Detection System
"""